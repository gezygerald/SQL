/*
Gerald
Onwude
*/
--Write a SQL query to retrieve loan number, state, city, UPB and todays date for loans in the
--state of TX that have a UPB greater than $100,000 or loans that are in the state of CA or FL that
--have a UPB greater than or equal to $500,000

select		loannumber, state, city, upb, getdate()
From		Loan
where state = 'TX' and upb > 100000
OR
State ='CA'or state = 'FL'
Having		upb >= 500000;

--Write a SQL query to retrieve loan number, customer first name, customer last name, property
--address, and bankruptcy attorney name. I want all the records that have the same attorney
--name to be together, then the customer last name in order from Z-A (ex.Customer last name of
--Wyatt comes before customer last name of Anderson)

select		loannumber, customerFname as First_name, CustomerLname as Last_name, propertyaddress, 
			bankruptcyattorneyname as Attorney
from		Loan
Group by	bankruptcyattorneyname, loannumber, customerFname, CustomerLname, propertyaddress
order by		CustomerLname desc

--Write a sql query to retrieve the loan number, state and city, customer first name for loans that
--are in the states of CA,TX,FL,NV,NM but exclude the following cities (Dallas, SanFrancisco,
--Oakland) and only return loans where customer first name begins with John.
select		loannumber, state, city, customerFname as First_name
from		loan
Where		state IN ('CA','Tx','Fl','Nv','Nm')
and  
not			city IN ( 'dallas' ,'sanfrancisco','oakland') 
and
			CustomerFname like ('%john%')

--Find out how many days old each Loan is?
select loannumber, customerLname, DATEDIFF (dd,  LoanDate, Getdate()) as Loan_days
from			Loan

--Find the State with the highest Avg UPB.
select top (1) State, AVG (upb) as Average_Upb
from	Loan
group by State

--Each Loan has a length of 30 years. Retrieve the LoanNumber, Attorney Name and the
--anticipated Finish Date of the Loan.

select loannumber, BankruptcyAttorneyName as Attorney_Name, Dateadd ("YEAR",30, loandate) as Anticipated_finish_date
from		loan
order by	LoanDate desc

--The Title of the Customer is Located in the CustomerFname Column. Separate the title into its
--own column and also retrieve CustomerFname, CustomerLname, City, State and LoanDate of
--Loans that are more than 1 yr old.
select		left (customerFname, 2), right (CustomerFname, 6)as First_name, 
customerLname as Last_name, city, state, LoanDate
from		loan
where loandate < DATEADD("year", -1, GetDate())


--Find another function not used above. Explain what it does. Create a Statement using the new function
--and post it to the discussions. Take a screenshot of the posted article, paste it to a Word Doc and
--submit it with this assignment.
Ucase & Lower
SELECT Upper('SQL Tutorial is FUN!') AS UppercaseText;
Select Lower('SQL Tutorial is FUN!') AS LowercaseText;